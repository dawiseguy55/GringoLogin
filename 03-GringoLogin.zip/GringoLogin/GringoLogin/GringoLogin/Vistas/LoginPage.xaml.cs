﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GringoLogin.Vistas
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        private double ancho = 0; //width
        private double alto = 0; //height
        public LoginPage()
        {
            InitializeComponent();
        }
        protected override void OnSizeAllocated(double ancho, double alto)
        {
            base.OnSizeAllocated(ancho, alto);
            //Comprobacion de orientacion 
            if (this.ancho != ancho && this.alto != alto)
            {
                this.ancho = ancho;
                this.alto = alto;

                //Ajustamos el tamaño del icono usando el BodyGrid, para iOS se ve mas mejor se el icono es un pocquito mas grande
                //if (Device.RuntimePlatform == Device.Android)
                //    LoginIcon.WidthRequest = (BodyGrid.Width / 2);
                //else
                //    LoginIcon.WidthRequest = (BodyGrid.Width / 1.6);
            }
        }
    }
}